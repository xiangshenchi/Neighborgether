package com.axy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AxyApplication {

    public static void main(String[] args) {
        SpringApplication.run(AxyApplication.class, args);
    }

}
