package com.axy.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.axy.pojo.Users;
import com.axy.service.UsersService;
import com.axy.mapper.UsersMapper;
import org.springframework.stereotype.Service;

/**
* @author DELL
* @description 针对表【users】的数据库操作Service实现
* @createDate 2024-08-17 15:41:45
*/
@Service
public class UsersServiceImpl extends ServiceImpl<UsersMapper, Users>
    implements UsersService{

}




