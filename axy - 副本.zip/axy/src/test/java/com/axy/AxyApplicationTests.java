package com.axy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AxyApplicationTests {

    @Test
    void contextLoads() {
    }

}
