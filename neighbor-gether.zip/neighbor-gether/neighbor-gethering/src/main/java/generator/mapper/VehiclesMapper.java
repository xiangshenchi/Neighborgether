package generator.mapper;

import generator.pojo.Vehicles;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
* @author DELL
* @description 针对表【vehicles】的数据库操作Mapper
* @createDate 2024-08-16 17:21:38
* @Entity generator.pojo.Vehicles
*/
public interface VehiclesMapper extends BaseMapper<Vehicles> {

}




