package generator.mapper;

import generator.pojo.Propertyinfo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
* @author DELL
* @description 针对表【propertyinfo】的数据库操作Mapper
* @createDate 2024-08-16 17:21:31
* @Entity generator.pojo.Propertyinfo
*/
public interface PropertyinfoMapper extends BaseMapper<Propertyinfo> {

}




