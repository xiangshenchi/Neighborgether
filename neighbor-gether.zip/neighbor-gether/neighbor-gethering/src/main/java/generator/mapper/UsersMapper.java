package generator.mapper;

import generator.pojo.Users;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
* @author DELL
* @description 针对表【users】的数据库操作Mapper
* @createDate 2024-08-16 17:21:36
* @Entity generator.pojo.Users
*/
public interface UsersMapper extends BaseMapper<Users> {

}




