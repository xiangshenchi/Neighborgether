package generator.mapper;

import generator.pojo.Demand;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
* @author DELL
* @description 针对表【demand】的数据库操作Mapper
* @createDate 2024-08-16 17:21:22
* @Entity generator.pojo.Demand
*/
public interface DemandMapper extends BaseMapper<Demand> {

}




