package generator.mapper;

import generator.pojo.Livingpayment;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
* @author DELL
* @description 针对表【livingpayment】的数据库操作Mapper
* @createDate 2024-08-16 17:21:28
* @Entity generator.pojo.Livingpayment
*/
public interface LivingpaymentMapper extends BaseMapper<Livingpayment> {

}




