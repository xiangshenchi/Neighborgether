package generator.service;

import generator.pojo.Demand;
import com.baomidou.mybatisplus.extension.service.IService;

/**
* @author DELL
* @description 针对表【demand】的数据库操作Service
* @createDate 2024-08-16 17:21:22
*/
public interface DemandService extends IService<Demand> {

}
