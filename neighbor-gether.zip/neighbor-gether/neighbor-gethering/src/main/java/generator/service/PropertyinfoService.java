package generator.service;

import generator.pojo.Propertyinfo;
import com.baomidou.mybatisplus.extension.service.IService;

/**
* @author DELL
* @description 针对表【propertyinfo】的数据库操作Service
* @createDate 2024-08-16 17:21:31
*/
public interface PropertyinfoService extends IService<Propertyinfo> {

}
