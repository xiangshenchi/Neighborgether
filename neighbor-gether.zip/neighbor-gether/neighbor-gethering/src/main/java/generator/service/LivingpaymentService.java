package generator.service;

import generator.pojo.Livingpayment;
import com.baomidou.mybatisplus.extension.service.IService;

/**
* @author DELL
* @description 针对表【livingpayment】的数据库操作Service
* @createDate 2024-08-16 17:21:28
*/
public interface LivingpaymentService extends IService<Livingpayment> {

}
