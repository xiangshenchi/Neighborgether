package generator.service;

import generator.pojo.Vehicles;
import com.baomidou.mybatisplus.extension.service.IService;

/**
* @author DELL
* @description 针对表【vehicles】的数据库操作Service
* @createDate 2024-08-16 17:21:38
*/
public interface VehiclesService extends IService<Vehicles> {

}
